export const adminFilterableFields = ['name', 'email', 'searchTerm', 'contactNumber'];

export const adminSearchAbleFields = ['name', 'email', 'contactNumber'];