export const scheduleFilterableFields: string[] = ['searchTerm', 'isBooked', 'doctorId'];
