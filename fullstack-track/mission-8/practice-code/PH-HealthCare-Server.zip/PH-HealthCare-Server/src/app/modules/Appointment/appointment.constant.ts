export const appointmentFilterableFields: string[] = [
    'status',
    'paymentStatus',
    'patientEmail',
    'doctorEmail'
];