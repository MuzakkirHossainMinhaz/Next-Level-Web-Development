export const prescriptionFilterableFields: string[] = [
    'patientEmail',
    'doctorEmail',
];