-- DropIndex
DROP INDEX "payments_transactionId_key";
