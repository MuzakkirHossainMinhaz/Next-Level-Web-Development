const DashboardHomePage = () => {
  return (
    <div>
      <h1>Welcome to dashboard</h1>
    </div>
  );
};

export default DashboardHomePage;
