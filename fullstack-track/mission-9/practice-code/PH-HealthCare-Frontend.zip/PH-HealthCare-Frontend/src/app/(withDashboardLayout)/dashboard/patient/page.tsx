const PatientPage = () => {
  return (
    <div>
      <h1>Patient Dashboard</h1>
    </div>
  );
};

export default PatientPage;
