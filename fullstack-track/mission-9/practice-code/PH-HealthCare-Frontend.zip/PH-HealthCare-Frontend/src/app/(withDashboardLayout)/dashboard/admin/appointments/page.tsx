const AppointmentsPage = () => {
  return (
    <div>
      <h1>Appointments Page</h1>
    </div>
  );
};

export default AppointmentsPage;
