import React from "react";

const SuperAdminPage = () => {
  return (
    <div>
      <h1>Super Admin Dashboard</h1>
    </div>
  );
};

export default SuperAdminPage;
