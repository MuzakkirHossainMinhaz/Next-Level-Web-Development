const DoctorPage = () => {
  return (
    <div>
      <h1>Doctor Dashboard</h1>
    </div>
  );
};

export default DoctorPage;
