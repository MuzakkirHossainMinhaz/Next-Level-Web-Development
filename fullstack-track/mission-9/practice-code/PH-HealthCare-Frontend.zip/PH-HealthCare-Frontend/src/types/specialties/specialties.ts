export type ISpecialties = {
   title: string;
   icon?: string;
   id?: string;
};
